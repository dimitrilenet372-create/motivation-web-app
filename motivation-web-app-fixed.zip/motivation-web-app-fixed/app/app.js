/* ═══════════════════════════════════════
   PERFECT DAY — APP JS
═══════════════════════════════════════ */

const CATEGORIES = [
  { id: 'sport',      name: 'Sport',      emoji: '🏃', color: 'blue'   },
  { id: 'business',   name: 'Business',   emoji: '💼', color: 'yellow' },
  { id: 'meditation', name: 'Méditation', emoji: '🧘', color: 'green'  },
  { id: 'goals',      name: 'Goals',      emoji: '🎯', color: 'red'    },
  { id: 'reading',    name: 'Lecture',    emoji: '📚', color: 'purple' },
  { id: 'health',     name: 'Santé',      emoji: '💪', color: 'pink'   },
  { id: 'finance',    name: 'Finance',    emoji: '💰', color: 'yellow' },
  { id: 'growth',     name: 'Growth',     emoji: '🌱', color: 'green'  },
  { id: 'sleep',      name: 'Sommeil',    emoji: '😴', color: 'blue'   },
];

const MONTH_NAMES  = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const DAY_SHORT    = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const DAY_FULL_FR  = ['Dimanche','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];
const MONTH_FR     = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];
let calWeekOffset  = 0;
let selectedDay    = null; /* set to today() after load */

const GOAL_COLORS = [
  { border: '#F97316', bg: '#FFF7ED' }, // orange
  { border: '#2563EB', bg: '#BFDBFE' }, // blue
  { border: '#16A34A', bg: '#BBFFD5' }, // green
  { border: '#7C3AED', bg: '#E9D5FF' }, // purple
  { border: '#DB2777', bg: '#FCE7F3' }, // pink
  { border: '#CA8A04', bg: '#FEF08A' }, // yellow
  { border: '#DC2626', bg: '#FFC9C9' }, // red
];
/* Maps old colorIndex → category color name (backwards compat) */
const COLORINDEX_MAP = ['blue', 'yellow', 'green', 'purple', 'pink', 'yellow', 'red'];

/* ── CHALLENGE PRESETS ── */
const CHALLENGE_SUGGESTIONS = {
  sport:      ['🏃 Courir', '💪 Musculation', '🧘 Yoga', '🚴 Vélo', '🏊 Natation', '🥊 HIIT'],
  business:   ['📊 Revue daily', '💡 Une idée/jour', '📩 Inbox zero', '🤝 Call client'],
  meditation: ['🌿 Méditation', '🌬️ Respiration', '🎧 Guidée', '🧘 Body scan'],
  goals:      ['🎯 Objectif perso', '📝 Journaling', '🌱 Nouvelle habitude'],
  reading:    ['📖 Lire', '📚 Non-fiction', '📰 Articles', '🧠 Flashcards'],
  health:     ['💧 Boire 2 L d\'eau', '🥗 Manger sain', '💊 Vitamines', '🚶 Marche'],
  finance:    ['💰 Épargner', '📈 Investir', '📋 Budget hebdo'],
  growth:     ['🌱 Apprendre', '🎓 Formation en ligne', '🤝 Réseauter'],
  sleep:      ['🌙 Coucher avant 23 h', '😴 8 h de sommeil', '📵 No écrans le soir'],
};

const CATEGORY_SUBTYPES = {
  sport:      ['Course', 'Musculation', 'Yoga', 'HIIT', 'Natation', 'Vélo', 'Football', 'Tennis', 'Boxe'],
  meditation: ['Pleine conscience', 'Respiration', 'Guidée', 'Body scan', 'Mantra', 'Visualisation'],
  reading:    ['Pages/jour', 'Minutes/jour', 'Chapitres/sem.'],
  sleep:      ['Heure de coucher', 'Durée de sommeil'],
  health:     ['Hydratation', 'Nutrition', 'Vitamines', 'Marche', 'Étirements'],
  growth:     ['Compétence', 'Langue', 'Instrument', 'Code', 'Cours en ligne'],
  business:   ['Stratégie', 'Prospection', 'Contenu', 'Admin'],
  finance:    ['Épargne', 'Investissement', 'Budget', 'Crypto'],
};

/* Categories that show a per-session duration picker */
const HAS_DURATION = new Set(['sport', 'meditation', 'reading', 'health', 'growth']);
/* Category that shows a bedtime picker */
const HAS_BEDTIME  = new Set(['sleep']);

/* ── SCOREBOARD ── */
function computeScore() {
  const items = [...state.challenges, ...state.goals];
  if (!items.length) return 0;
  const sum = items.reduce((s, x) => s + Math.min(1, (x.progress || 0) / (x.target || 1)), 0);
  return Math.round(sum / items.length * 100);
}

function toB64(str) {
  return btoa(unescape(encodeURIComponent(str)))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function fromB64(str) {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) str += '=';
  return decodeURIComponent(escape(atob(str)));
}

function generateShareURL() {
  const payload = {
    n: state.user.name,
    s: computeScore(),
    c: state.challenges.map(c => ({ e: c.emoji, n: c.name, p: c.progress, t: c.target })),
    g: state.goals.map(g => ({ e: g.emoji, n: g.name, p: g.progress, t: g.target })),
    d: today(),
  };
  return `${location.origin}${location.pathname}?friend=${toB64(JSON.stringify(payload))}`;
}

function parseFriendURL(input) {
  try {
    input = input.trim();
    let param = null;
    /* Try full URL first */
    if (input.startsWith('http')) {
      try { param = new URL(input).searchParams.get('friend'); } catch {}
    }
    /* Fallback: extract ?friend= or &friend= from string */
    if (!param) {
      const m = input.match(/[?&]friend=([^&\s]+)/);
      if (m) param = decodeURIComponent(m[1]);
    }
    /* Last resort: assume raw base64 was pasted */
    if (!param) param = input;
    if (!param) return null;
    return JSON.parse(fromB64(param));
  } catch { return null; }
}

function addFriend(data) {
  if (!state.friends) state.friends = [];
  const idx = state.friends.findIndex(f => f.n === data.n);
  if (idx >= 0) state.friends[idx] = data; else state.friends.push(data);
  save();
}

function checkShareURL() {
  const param = new URLSearchParams(location.search).get('friend');
  if (!param) return;
  history.replaceState({}, '', location.pathname);
  try {
    const data = JSON.parse(fromB64(param));
    if (!data?.n) return;
    if (confirm(`Ajouter ${data.n} à ton classement ? (Score : ${data.s} %)`)) {
      addFriend(data);
      showTab('tab-scores');
    }
  } catch {}
}

let state = {
  user: { name: '', onboarded: false },
  challenges: [],
  goals: [],
  friends: [],
};

/* ── STORAGE ── */
function save() {
  localStorage.setItem('perfectday', JSON.stringify(state));
}
function load() {
  const raw = localStorage.getItem('perfectday');
  if (raw) {
    state = JSON.parse(raw);
    if (!state.friends) state.friends = [];
  }
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function isDoneToday(challenge) {
  return (challenge.completions || []).includes(today());
}

/* Maps real % to a more visible fill % (power curve + minimum) */
function visualFill(pct, minPct = 8) {
  if (pct <= 0) return 0;
  if (pct >= 100) return 100;
  return Math.max(minPct, Math.round(Math.pow(pct / 100, 0.5) * 100));
}

/* ── ROUTING ── */
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function showTab(id) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('.nav-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.tab === id);
  });
  renderCurrentTab(id);
}

function renderCurrentTab(id, animate = true) {
  if (id === 'tab-home')     renderHome(animate);
  if (id === 'tab-scores')   renderScoreboard();
  if (id === 'tab-tracking') renderTracking();
  if (id === 'tab-profile')  renderProfile();
  if (id === 'tab-add')      renderAddTab();
}

/* ── WEEK CALENDAR ── */
function getMondayOfWeek(offset) {
  const now  = new Date();
  const day  = now.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  const mon  = new Date(now);
  mon.setHours(0, 0, 0, 0);
  mon.setDate(now.getDate() + diff + offset * 7);
  return mon;
}

function renderWeekStrip() {
  const strip = document.getElementById('week-strip');
  if (!strip) return;
  const monday   = getMondayOfWeek(calWeekOffset);
  const todayStr = today();

  /* Month label: use Thursday (mid-week) to decide which month to show */
  const thu = new Date(monday);
  thu.setDate(monday.getDate() + 3);
  const lbl = document.getElementById('week-month-label');
  if (lbl) lbl.textContent = MONTH_NAMES[thu.getMonth()];

  /* Collect days with at least one completed challenge for the orange dot */
  const doneDates = new Set();
  state.challenges.forEach(c => (c.completions || []).forEach(d => doneDates.add(d)));

  strip.innerHTML = '';
  for (let i = 0; i < 7; i++) {
    const d    = new Date(monday);
    d.setDate(monday.getDate() + i);
    const dStr    = d.toISOString().slice(0, 10);
    const isToday = dStr === todayStr;
    const isPast  = dStr < todayStr;
    const hasDone = doneDates.has(dStr);
    const isSel   = dStr === (selectedDay || todayStr);

    const col = document.createElement('div');
    col.className = `day-col${isToday ? ' today' : isPast ? ' past' : ' future'}${isSel ? ' selected' : ''}`;
    col.innerHTML = `
      <span class="day-col-name">${DAY_SHORT[i]}</span>
      <div class="day-col-num-wrap"><span class="day-col-num">${d.getDate()}</span></div>
      <div class="day-dot${hasDone ? ' done' : ''}"></div>`;
    col.addEventListener('click', () => {
      selectedDay = dStr;
      renderWeekStrip();
      renderDaySummary();
    });
    strip.appendChild(col);
  }
}

function renderDaySummary() {
  const el = document.getElementById('day-summary');
  if (!el) return;
  const sel = selectedDay || today();

  if (sel === today()) { el.innerHTML = ''; return; }

  if (sel > today()) {
    el.innerHTML = `<div class="day-summary-card"><div class="ds-empty">Aucune donnée pour ce jour</div></div>`;
    return;
  }

  const d      = new Date(sel + 'T00:00:00');
  const label  = `${DAY_FULL_FR[d.getDay()]} ${d.getDate()} ${MONTH_FR[d.getMonth()]}`;
  const done   = state.challenges.filter(c => (c.completions || []).includes(sel));
  const missed = state.challenges.filter(c => !(c.completions || []).includes(sel));

  el.innerHTML = `
    <div class="day-summary-card">
      <div class="ds-hdr">
        <span class="ds-date">${label}</span>
        <span class="ds-score">${done.length} / ${state.challenges.length}</span>
      </div>
      <div class="ds-list">
        ${done.map(c   => `<div class="ds-item ds-done">${c.emoji} ${c.name}</div>`).join('')}
        ${missed.map(c => `<div class="ds-item ds-missed">${c.emoji} ${c.name}</div>`).join('')}
      </div>
    </div>`;
}

document.getElementById('week-prev').addEventListener('click', () => { calWeekOffset--; renderWeekStrip(); });
document.getElementById('week-next').addEventListener('click', () => { calWeekOffset++; renderWeekStrip(); });
document.getElementById('cal-today-btn').addEventListener('click', () => {
  calWeekOffset = 0; selectedDay = today();
  renderWeekStrip(); renderDaySummary();
});

/* ── HOME ── */
function renderHome(animate = true) {
  if (!selectedDay) selectedDay = today();
  document.getElementById('user-name-display').textContent = state.user.name;
  renderWeekStrip();
  renderDaySummary();
  renderGoalsList(animate);
  renderChallengesHome(animate);
}

function renderGoalsList(animate = true, updatedId = null) {
  const el = document.getElementById('goals-list');
  if (!state.goals.length) {
    el.innerHTML = '<button class="btn-add-first-goal" id="add-first-goal">Add your first goal</button>';
    document.getElementById('add-first-goal').addEventListener('click', openGoalModal);
    return;
  }
  el.innerHTML = state.goals.map(g => goalCardHTML(g)).join('');
  if (updatedId) {
    const updatedRow = el.querySelector(`.goal-row[data-id="${updatedId}"] .goal-card`);
    if (updatedRow) {
      const fill = updatedRow.dataset.fill;
      if (fill) updatedRow.style.setProperty('--fill', fill);
    }
  } else {
    animateFills(el);
  }
  if (animate) addEntryStagger(el, '.goal-row');
  el.querySelectorAll('.goal-action').forEach(btn => {
    btn.addEventListener('click', () => {
      const g = state.goals.find(x => x.id === btn.dataset.id);
      if (!g || g.paused || g.progress >= g.target) return;
      const r        = btn.getBoundingClientRect();
      const accColor = CAT_COLORS[btn.dataset.color] || '#F97316';
      spawnFloatText(r.left + r.width / 2, r.top, '+1', accColor);
      g.progress++;
      save();
      const willComplete = g.progress >= g.target;
      renderGoalsList(false, g.id);
      const newCard = el.querySelector(`.goal-row[data-id="${g.id}"] .goal-card`);
      addShine(newCard);
      if (willComplete) {
        pulseRing(newCard, 'rgba(22,163,74,.55)');
        spawnConfetti(r.left + r.width / 2, r.top + r.height / 2);
        showToast(`🏆 ${g.name} — objectif atteint !`);
      }
    });
  });
  el.querySelectorAll('.goal-swipe-pause').forEach(btn => {
    btn.addEventListener('click', () => {
      const g = state.goals.find(x => x.id === btn.dataset.id);
      if (g) { g.paused = !g.paused; save(); renderGoalsList(); }
    });
  });
  el.querySelectorAll('.goal-swipe-delete').forEach(btn => {
    btn.addEventListener('click', () => {
      if (!confirm('Supprimer ce goal ?')) return;
      state.goals = state.goals.filter(x => x.id !== btn.dataset.id);
      save();
      renderGoalsList();
    });
  });
  initGoalSwipe(el);
}

function goalCardHTML(g) {
  const pct      = Math.min(100, (g.progress / g.target) * 100);
  const complete = g.progress >= g.target;
  const color    = g.color || COLORINDEX_MAP[g.colorIndex ?? 0] || 'blue';
  const fill     = complete ? 100 : visualFill(pct, 5);
  const colorClass = (complete || g.paused) ? '' : `color-${color}`;
  const rowClass   = complete ? 'is-complete' : g.paused ? 'is-paused' : '';
  return `
    <div class="goal-row ${rowClass}" data-id="${g.id}">
      <div class="goal-swipe-actions">
        <button class="goal-swipe-pause" data-id="${g.id}">
          <span class="goal-swipe-icon">${g.paused ? '▶' : '⏸'}</span>
          ${g.paused ? 'Reprise' : 'Pause'}
        </button>
        <button class="goal-swipe-delete" data-id="${g.id}">
          <span class="goal-swipe-icon">✕</span>
          Supp.
        </button>
      </div>
      <div class="goal-card ${colorClass} ${g.paused ? 'paused' : ''}" style="--fill:0%" data-fill="${fill}%">
        <span class="goal-emoji">${g.emoji}</span>
        <div class="goal-info">
          <div class="goal-name">${g.name}${complete ? ' ✓' : ''}</div>
          <div class="goal-prog">${complete ? 'Objectif atteint 🎉' : `${g.progress}/${g.target}${g.paused ? ' · En pause' : ''}`}</div>
        </div>
        ${(!g.paused && !complete) ? `<button class="goal-action" data-id="${g.id}" data-color="${color}">+1</button>` : ''}
        ${complete ? `<span class="goal-complete-badge">🏆</span>` : ''}
      </div>
    </div>`;
}

function renderChallengesHome(animate = true) {
  const el = document.getElementById('challenges-home-list');
  if (!state.challenges.length) {
    el.innerHTML = '<div class="empty-state">Aucun challenge — va dans "Add" pour en créer un</div>';
    return;
  }
  el.innerHTML = state.challenges.slice(0, 5).map(c => challengeCardHTML(c)).join('');
  animateFills(el);
  if (animate) addEntryStagger(el, '.challenge-row');
  bindChallengeActions(el);
  if (timerState.cid) {
    const ac = state.challenges.find(x => x.id === timerState.cid);
    if (ac) applyTimerToCard(ac);
  }
}

/* ── CHALLENGE CARD ── */
function buildSubtitle(c) {
  const parts = [];
  if (c.subtype)   parts.push(c.subtype);
  if (c.duration)  parts.push(`${c.duration} min`);
  if (c.bedtime)   parts.push(`🌙 ${c.bedtime}`);
  return parts.length ? `<div class="ch-subtitle">${parts.join(' · ')}</div>` : '';
}

function challengeCardHTML(c) {
  const done     = isDoneToday(c);
  const complete = c.progress >= c.target;
  const pct      = Math.min(100, (c.progress / c.target) * 100);
  const fill     = complete ? 100 : visualFill(pct);
  const colorClass = complete ? 'is-complete' : done ? 'done-today' : 'color-' + c.color;
  return `
    <div class="challenge-row" data-id="${c.id}">
      <div class="challenge-swipe-del">
        <button class="ch-del-btn" data-id="${c.id}">
          <span class="ch-del-icon">✕</span>Supp.
        </button>
      </div>
      <div class="challenge-card ${colorClass}" style="--fill:0%" data-fill="${fill}%">
        <div class="ch-avatar">${c.emoji}</div>
        <div class="ch-info">
          <div class="ch-name">${c.name}${complete ? ' ✓' : ''}</div>
          ${buildSubtitle(c)}
          <div class="ch-prog">${complete ? 'Challenge terminé 🎉' : `${c.progress}/${c.target} jours`}</div>
        </div>
        ${complete
          ? '<span class="ch-complete-badge">🏆</span>'
          : `<button class="ch-action ${done ? 'done' : ''}" data-id="${c.id}">${done ? '✓' : '+1'}</button>`}
      </div>
    </div>`;
}

const CAT_COLORS = { blue:'#2563EB', green:'#16A34A', red:'#DC2626', yellow:'#CA8A04', purple:'#7C3AED', pink:'#DB2777' };

function completeChallengeToday(c) {
  if (!c.completions) c.completions = [];
  c.completions.push(today());
  c.progress = Math.min(c.progress + 1, c.target);
  save();
  const willComplete = c.progress >= c.target;
  const col = CAT_COLORS[c.color] || '#F97316';
  const cx = window.innerWidth / 2;
  const cy = window.innerHeight * 0.38;
  const activeTabId = document.querySelector('.tab.active').id;
  if (activeTabId === 'tab-home') {
    renderChallengesHome(false);
    renderGoalsList(false);
  }
  const activeTab = document.querySelector('.tab.active');
  const newChCard = activeTab.querySelector(`.challenge-row[data-id="${c.id}"] .challenge-card`);
  addShine(newChCard);
  if (willComplete) {
    pulseRing(newChCard, `${col}88`);
    spawnConfetti(cx, cy);
    showToast(`🏆 ${c.name} — challenge terminé !`);
  } else {
    spawnFloatText(cx, cy, '+1', col);
  }
}

function bindChallengeActions(container) {
  container.querySelectorAll('.ch-action').forEach(btn => {
    btn.addEventListener('click', () => {
      const c = state.challenges.find(x => x.id === btn.dataset.id);
      if (!c || isDoneToday(c) || c.progress >= c.target) return;
      openTimer(c);
    });
  });
  container.querySelectorAll('.ch-del-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (!confirm('Supprimer ce challenge ?')) return;
      state.challenges = state.challenges.filter(x => x.id !== btn.dataset.id);
      save();
      renderCurrentTab(document.querySelector('.tab.active').id);
    });
  });
  initChallengeSwipe(container);
}

/* ── ALL CHALLENGES ── */
function renderAllChallenges(animate = true) {
  const el = document.getElementById('all-challenges-list');
  if (!state.challenges.length) {
    el.innerHTML = '<div class="empty-state" style="margin:0">Aucun challenge</div>';
    return;
  }
  el.innerHTML = state.challenges.map(c => challengeCardHTML(c)).join('');
  animateFills(el);
  if (animate) addEntryStagger(el, '.challenge-row');
  bindChallengeActions(el);
}

/* ── TRACKING ── */
function renderTracking() {
  const el = document.getElementById('tracking-list');
  if (!state.challenges.length) {
    el.innerHTML = '<div class="empty-state" style="margin:0">Aucun challenge à tracker</div>';
    return;
  }
  el.innerHTML = state.challenges.map(c => {
    const pct = Math.min(100, (c.progress / c.target) * 100).toFixed(1);
    const streak = getStreak(c);
    return `
      <div class="tracking-card">
        <div class="tracking-header">
          <span class="tracking-emoji">${c.emoji}</span>
          <span class="tracking-name">${c.name}</span>
          <span class="tracking-pct">${pct}%</span>
        </div>
        <div class="tracking-body">
          <div class="progress-bar-big">
            <div class="progress-bar-fill" style="width:0%" data-fill="${pct}%"></div>
          </div>
          <div class="tracking-stats">
            <div class="tracking-stat">
              <span class="tracking-stat-num">${c.progress}</span>
              <span class="tracking-stat-label">jours</span>
            </div>
            <div class="tracking-stat">
              <span class="tracking-stat-num">${c.target - c.progress}</span>
              <span class="tracking-stat-label">restants</span>
            </div>
            <div class="tracking-stat">
              <span class="tracking-stat-num">${streak} 🔥</span>
              <span class="tracking-stat-label">streak</span>
            </div>
          </div>
        </div>
      </div>`;
  }).join('');
  animateFills(el);
}

function getStreak(c) {
  if (!c.completions || !c.completions.length) return 0;
  const sorted = [...c.completions].sort().reverse();
  let streak = 0;
  let d = new Date();
  for (const dateStr of sorted) {
    const expected = d.toISOString().slice(0, 10);
    if (dateStr === expected) {
      streak++;
      d.setDate(d.getDate() - 1);
    } else break;
  }
  return streak;
}

/* ── PROFILE ── */
function renderProfile() {
  document.getElementById('profile-name-display').textContent = state.user.name;
  const done  = state.challenges.filter(c => isDoneToday(c)).length;
  const total = state.challenges.length;
  const best  = state.challenges.reduce((m, c) => Math.max(m, getStreak(c)), 0);
  document.getElementById('profile-stats').innerHTML = `
    <div class="stat-box"><div class="stat-num">${total}</div><div class="stat-label">Challenges</div></div>
    <div class="stat-box"><div class="stat-num">${done}</div><div class="stat-label">Aujourd'hui</div></div>
    <div class="stat-box"><div class="stat-num">${best}</div><div class="stat-label">Best streak</div></div>
  `;
}

function renderScoreboard() {
  const myScore = computeScore();
  document.getElementById('my-score-num').textContent = `${myScore} %`;

  const friends = state.friends || [];
  const all = [
    { name: state.user.name || 'Toi', score: myScore, isMe: true,
      sub: `${state.challenges.length} challenges · ${state.goals.length} goals` },
    ...friends.map(f => ({
      name: f.n, score: f.s, isMe: false,
      sub: `${(f.c||[]).length} challenges · ${(f.g||[]).length} goals · ${f.d || ''}`,
    })),
  ].sort((a, b) => b.score - a.score);

  const medals = ['🥇','🥈','🥉'];
  const el = document.getElementById('leaderboard');
  if (all.length <= 1) {
    el.innerHTML = '<div class="no-friends-msg">Partage ton lien pour te comparer à tes amis !</div>';
    return;
  }
  el.innerHTML = all.map((p, i) => `
    <div class="friend-row ${p.isMe ? 'is-me' : ''}">
      <span class="friend-rank">${medals[i] || (i + 1)}</span>
      <div class="friend-detail">
        <div class="friend-name">${p.name}</div>
        <div class="friend-sub">${p.sub}</div>
        <div class="friend-score-bar"><div class="friend-score-fill" style="width:0%" data-fill="${p.score}%"></div></div>
      </div>
      <span class="friend-score">${p.score}%</span>
    </div>`).join('');
  animateFills(el);
}

/* ── ADD TAB ── */
let addSelectedCat  = null;
let addTarget       = 365;
let addSubtype      = '';
let addDuration     = 20;
let editChallengeId = null;

function syncPresets(presetsId, val) {
  document.querySelectorAll(`#${presetsId} .preset-btn`).forEach(btn => {
    btn.classList.toggle('active', Number(btn.dataset.days) === val);
  });
}
function syncDurPresets(val) {
  document.querySelectorAll('#dur-presets .preset-btn').forEach(btn => {
    btn.classList.toggle('active', Number(btn.dataset.mins) === val);
  });
}

function showDurPicker() {
  document.getElementById('add-duration-wrap').classList.remove('hidden');
  document.getElementById('dur-add-btn').classList.add('hidden');
}
function hideDurPicker() {
  document.getElementById('add-duration-wrap').classList.add('hidden');
  document.getElementById('dur-add-btn').classList.remove('hidden');
  addDuration = 20;
}

function renderAddTab() {
  editChallengeId = null;
  document.getElementById('save-challenge').textContent = 'Ajouter le challenge';
  addSelectedCat = null;
  addTarget      = 365;
  addSubtype     = '';
  addDuration    = 20;
  document.getElementById('t-val').value = addTarget;
  syncPresets('t-presets', addTarget);
  document.getElementById('new-name').value = '';
  document.getElementById('add-form').classList.add('hidden');
  document.getElementById('add-suggestions').classList.add('hidden');
  document.getElementById('add-suggestions').innerHTML = '';
  document.getElementById('add-duration-wrap').classList.add('hidden');
  document.getElementById('dur-add-btn').classList.add('hidden');
  document.getElementById('add-bedtime-wrap').classList.add('hidden');
  document.getElementById('add-subtype-wrap').classList.add('hidden');

  buildCatGrid('add-cat-grid', (cat) => {
    addSelectedCat = cat;
    addSubtype     = '';
    document.getElementById('new-name').value = cat.name;
    document.getElementById('add-form').classList.remove('hidden');

    /* 1. Suggestions de noms */
    const sugs = CHALLENGE_SUGGESTIONS[cat.id] || [];
    const sugWrap = document.getElementById('add-suggestions');
    if (sugs.length) {
      sugWrap.innerHTML = sugs.map(s =>
        `<button class="suggestion-chip">${s}</button>`).join('');
      sugWrap.classList.remove('hidden');
      sugWrap.querySelectorAll('.suggestion-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          document.getElementById('new-name').value = chip.textContent.trim();
        });
      });
    } else {
      sugWrap.classList.add('hidden');
    }

    /* 2. Sous-types */
    const subtypes = CATEGORY_SUBTYPES[cat.id] || [];
    const stWrap   = document.getElementById('add-subtype-wrap');
    const stChips  = document.getElementById('add-subtype-chips');
    if (subtypes.length) {
      stChips.innerHTML = subtypes.map(s =>
        `<button class="subtype-chip" data-val="${s}">${s}</button>`).join('');
      stWrap.classList.remove('hidden');
      stChips.querySelectorAll('.subtype-chip').forEach(chip => {
        chip.addEventListener('click', () => {
          stChips.querySelectorAll('.subtype-chip').forEach(c => c.classList.remove('active'));
          chip.classList.add('active');
          addSubtype = chip.dataset.val;
        });
      });
    } else {
      stWrap.classList.add('hidden');
    }

    /* 3. Durée : visible pour les catégories compatibles */
    addDuration = 20;
    document.getElementById('dur-val').value = addDuration;
    syncDurPresets(addDuration);
    document.getElementById('dur-add-btn').classList.add('hidden');
    if (HAS_DURATION.has(cat.id)) {
      document.getElementById('add-duration-wrap').classList.remove('hidden');
    } else {
      document.getElementById('add-duration-wrap').classList.add('hidden');
    }

    /* 4. Heure de coucher — UNIQUEMENT catégorie sleep */
    const btWrap = document.getElementById('add-bedtime-wrap');
    if (cat.id === 'sleep') {
      btWrap.classList.remove('hidden');
    } else {
      btWrap.classList.add('hidden');
    }
  });

  document.getElementById('dur-add-btn').onclick = showDurPicker;
  document.getElementById('dur-remove').onclick   = hideDurPicker;
}

function buildCatGrid(containerId, onSelect) {
  const el = document.getElementById(containerId);
  el.innerHTML = CATEGORIES.map(c => `
    <div class="cat-item" data-id="${c.id}">
      <span class="cat-emoji">${c.emoji}</span>
      <span class="cat-name">${c.name}</span>
    </div>`).join('');
  el.querySelectorAll('.cat-item').forEach(item => {
    item.addEventListener('click', () => {
      el.querySelectorAll('.cat-item').forEach(i => i.classList.remove('selected'));
      item.classList.add('selected');
      const cat = CATEGORIES.find(c => c.id === item.dataset.id);
      if (cat) onSelect(cat);
    });
  });
}

/* ── TOAST ── */
function showToast(msg) {
  const app = document.getElementById('app');
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = msg;
  app.appendChild(t);
  requestAnimationFrame(() => { requestAnimationFrame(() => t.classList.add('show')); });
  setTimeout(() => {
    t.classList.remove('show');
    t.classList.add('hide');
    setTimeout(() => t.remove(), 300);
  }, 2800);
}

/* ── ANIMATION HELPERS ── */
function spawnFloatText(x, y, text, color) {
  const el = document.createElement('div');
  el.className = 'float-label';
  el.textContent = text;
  el.style.cssText = `left:${x}px; top:${y}px; color:${color};`;
  document.body.appendChild(el);
  el.addEventListener('animationend', () => el.remove(), { once: true });
}

function spawnConfetti(x, y) {
  const COLS = ['#F97316','#2563EB','#16A34A','#7C3AED','#DB2777','#CA8A04','#FBBF24','#DC2626'];
  for (let i = 0; i < 20; i++) {
    const dot = document.createElement('div');
    dot.className = 'confetti-bit';
    const angle = (i / 20) * 2 * Math.PI + Math.random() * 0.5;
    const dist  = 40 + Math.random() * 65;
    dot.style.cssText = `
      left:${x}px; top:${y}px;
      background:${COLS[i % COLS.length]};
      --tx:${(Math.cos(angle) * dist).toFixed(1)}px;
      --ty:${(Math.sin(angle) * dist).toFixed(1)}px;
      --tr:${Math.round(Math.random() * 540)}deg;
      animation-delay:${(Math.random() * 0.08).toFixed(3)}s;
      border-radius:${Math.random() > 0.5 ? '50%' : '3px'};
    `;
    document.body.appendChild(dot);
    dot.addEventListener('animationend', () => dot.remove(), { once: true });
  }
}

function pulseRing(el, color = 'rgba(22,163,74,.55)') {
  if (!el) return;
  el.style.setProperty('--ring-col', color);
  el.classList.remove('anim-ring');
  void el.offsetWidth;
  el.classList.add('anim-ring');
  el.addEventListener('animationend', () => el.classList.remove('anim-ring'), { once: true });
}

function addEntryStagger(container, selector) {
  container.querySelectorAll(selector).forEach((el, i) => {
    el.style.animation = `fadeSlideUp 0.28s ease-out ${(i * 0.055).toFixed(3)}s both`;
  });
}

function addShine(el) {
  if (!el) return;
  el.classList.remove('anim-shine');
  void el.offsetWidth;
  el.classList.add('anim-shine');
  setTimeout(() => el.classList.remove('anim-shine'), 700);
}

function animateFills(container) {
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      container.querySelectorAll('[data-fill]').forEach(el => {
        const val = el.dataset.fill;
        if (el.classList.contains('progress-bar-fill') || el.classList.contains('friend-score-fill')) {
          el.style.width = val;
        } else {
          el.style.setProperty('--fill', val);
        }
      });
    });
  });
}

/* ── TIMER (in-card) ── */
const timerState = {
  cid: null, totalMs: 0, startTs: 0,
  elapsed: 0, paused: false, pausedAt: 0, raf: null, cardEl: null,
};

function openTimer(c) {
  const mins = c.duration || 20;
  timerState.cid     = c.id;
  timerState.totalMs = mins * 60 * 1000;
  timerState.elapsed = 0;
  timerState.paused  = false;
  timerState.startTs = performance.now();
  applyTimerToCard(c);
  timerState.raf = requestAnimationFrame(tickTimer);
}

function applyTimerToCard(c) {
  const card = document.querySelector(`.challenge-row[data-id="${c.id}"] .challenge-card`);
  if (!card) return;
  timerState.cardEl = card;
  card.classList.add('timer-active');
  card.style.setProperty('--fill', '0%');
  const remaining = (timerState.totalMs - timerState.elapsed) / 1000;
  card.innerHTML = `
    <div class="ch-avatar">${c.emoji}</div>
    <div class="ch-info">
      <div class="ch-name">${c.name}</div>
      <div class="ch-timer-cd">${fmtTime(remaining)}</div>
    </div>
    <div class="ch-timer-btns">
      <button class="ch-tb-cancel">✕</button>
      <button class="ch-tb-pause">⏸</button>
      <button class="ch-tb-done">✓</button>
    </div>`;
  card.querySelector('.ch-tb-cancel').addEventListener('click', cancelTimerInCard);
  card.querySelector('.ch-tb-pause').addEventListener('click', pauseResumeTimer);
  card.querySelector('.ch-tb-done').addEventListener('click', () => finishTimer(true));
}

function tickTimer(ts) {
  if (timerState.paused) return;
  timerState.elapsed   = ts - timerState.startTs;
  const progress       = Math.min(1, timerState.elapsed / timerState.totalMs);
  const remaining      = Math.max(0, timerState.totalMs - timerState.elapsed);
  const card           = timerState.cardEl;

  if (card && card.isConnected) {
    card.style.setProperty('--fill', `${(progress * 100).toFixed(2)}%`);
    const cd = card.querySelector('.ch-timer-cd');
    if (cd) cd.textContent = fmtTime(remaining / 1000);
  } else if (timerState.cid) {
    const c = state.challenges.find(x => x.id === timerState.cid);
    if (c) applyTimerToCard(c);
  }

  if (progress >= 1) { finishTimer(true); return; }
  timerState.raf = requestAnimationFrame(tickTimer);
}

function fmtTime(totalSeconds) {
  const s = Math.ceil(totalSeconds);
  const m = Math.floor(s / 60);
  return `${String(m).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

function pauseResumeTimer() {
  const btn = timerState.cardEl?.querySelector('.ch-tb-pause');
  if (timerState.paused) {
    timerState.startTs += performance.now() - timerState.pausedAt;
    timerState.paused   = false;
    if (btn) btn.textContent = '⏸';
    timerState.raf = requestAnimationFrame(tickTimer);
  } else {
    timerState.paused   = true;
    timerState.pausedAt = performance.now();
    cancelAnimationFrame(timerState.raf);
    if (btn) btn.textContent = '▶';
  }
}

function finishTimer(success = true) {
  cancelAnimationFrame(timerState.raf);
  const cid = timerState.cid;
  timerState.cid = null; timerState.cardEl = null;
  const c = state.challenges.find(x => x.id === cid);
  if (!c) return;
  if (success && !isDoneToday(c) && c.progress < c.target) {
    completeChallengeToday(c);
  } else {
    renderChallengesHome(false);
  }
}

function cancelTimerInCard() {
  cancelAnimationFrame(timerState.raf);
  timerState.cid = null; timerState.cardEl = null;
  renderChallengesHome(false);
}

/* ── EDIT CHALLENGE ── */
function openEditChallenge(c) {
  editChallengeId = c.id;
  showTab('tab-add'); /* calls renderAddTab which resets form */

  /* Pre-select category */
  const catEl = document.querySelector(`#add-cat-grid .cat-item[data-id="${c.category}"]`);
  if (catEl) catEl.click();

  /* Override name (catEl.click sets it to cat.name) */
  document.getElementById('new-name').value = c.name;

  /* Pre-select subtype chip */
  if (c.subtype) {
    const chip = document.querySelector(`#add-subtype-chips .subtype-chip[data-val="${c.subtype}"]`);
    if (chip) chip.click();
  }

  /* Pre-fill duration */
  if (c.duration) {
    addDuration = c.duration;
    document.getElementById('dur-val').value = c.duration;
    syncDurPresets(c.duration);
  }

  /* Pre-fill bedtime */
  if (c.bedtime) document.getElementById('add-bedtime').value = c.bedtime;

  /* Pre-fill target */
  addTarget = c.target;
  document.getElementById('t-val').value = c.target;
  syncPresets('t-presets', c.target);

  /* Change button label */
  document.getElementById('save-challenge').textContent = 'Sauvegarder';
}

/* ── GOAL SWIPE ── */
const SWIPE_W = 130;

function togglePause(id) {
  const g = state.goals.find(x => x.id === id);
  if (g) { g.paused = !g.paused; save(); renderGoalsList(); }
}

function initGoalSwipe(container) {
  container.querySelectorAll('.goal-row').forEach(row => {
    const card = row.querySelector('.goal-card');
    let startX = 0, startY = 0, tracking = false;

    card.addEventListener('touchstart', e => {
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
      tracking = true;
      row._wasTouched = true;
      card.style.transition = 'none';
    }, { passive: true });

    card.addEventListener('touchmove', e => {
      if (!tracking) return;
      if (row.classList.contains('is-paused')) { tracking = false; return; }
      const dx = e.touches[0].clientX - startX;
      const dy = e.touches[0].clientY - startY;
      if (!row._swiped && Math.abs(dy) > Math.abs(dx) + 4) { tracking = false; return; }
      const base = row._swiped ? -SWIPE_W : 0;
      const x = Math.max(-SWIPE_W, Math.min(0, base + dx));
      card.style.transform = `translateX(${x}px)`;
    }, { passive: true });

    card.addEventListener('touchend', e => {
      if (!tracking) return;
      tracking = false;
      card.style.transition = `transform 0.28s var(--ease-out)`;
      const dx = e.changedTouches[0].clientX - startX;
      const dy = e.changedTouches[0].clientY - startY;
      const isTap = Math.abs(dx) < 8 && Math.abs(dy) < 8;

      if (row.classList.contains('is-paused')) {
        if (isTap) togglePause(row.dataset.id);
        return;
      }
      const base = row._swiped ? -SWIPE_W : 0;
      if (base + dx < -SWIPE_W / 3) {
        openGoalSwipe(row);
      } else {
        closeGoalSwipe(row);
      }
    });

    card.addEventListener('click', e => {
      if (row._wasTouched) { row._wasTouched = false; return; }
      if (e.target.closest('.goal-action')) return;
      if (row.classList.contains('is-paused')) { togglePause(row.dataset.id); return; }
      row._swiped ? closeGoalSwipe(row) : openGoalSwipe(row);
    });
  });
}

function openGoalSwipe(row) {
  closeAllGoalSwipes();
  const card = row.querySelector('.goal-card');
  card.style.transition = `transform 0.28s var(--ease-out)`;
  card.style.transform = `translateX(-${SWIPE_W}px)`;
  row._swiped = true;
}

function closeGoalSwipe(row) {
  const card = row.querySelector('.goal-card');
  card.style.transition = `transform 0.28s var(--ease-out)`;
  card.style.transform = 'translateX(0)';
  row._swiped = false;
}

function closeAllGoalSwipes() {
  document.querySelectorAll('.goal-row').forEach(r => { if (r._swiped) closeGoalSwipe(r); });
}

/* ── CHALLENGE SWIPE ── */
const CH_SWIPE_W = 80;

function initChallengeSwipe(container) {
  container.querySelectorAll('.challenge-row').forEach(row => {
    const card = row.querySelector('.challenge-card');
    let startX = 0, startY = 0, tracking = false;

    card.addEventListener('touchstart', e => {
      if (card.classList.contains('timer-active')) return;
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
      tracking = true;
      row._wasTouched = true;
      card.style.transition = 'none';
    }, { passive: true });

    card.addEventListener('touchmove', e => {
      if (!tracking || card.classList.contains('timer-active')) return;
      const dx = e.touches[0].clientX - startX;
      const dy = e.touches[0].clientY - startY;
      if (!row._swiped && Math.abs(dy) > Math.abs(dx) + 4) { tracking = false; return; }
      const base = row._swiped ? -CH_SWIPE_W : 0;
      card.style.transform = `translateX(${Math.max(-CH_SWIPE_W, Math.min(0, base + dx))}px)`;
    }, { passive: true });

    card.addEventListener('touchend', e => {
      if (!tracking) return;
      tracking = false;
      card.style.transition = `transform 0.28s var(--ease-out)`;
      const dx = e.changedTouches[0].clientX - startX;
      const base = row._swiped ? -CH_SWIPE_W : 0;
      base + dx < -CH_SWIPE_W / 3 ? openChallengeSwipe(row) : closeChallengeSwipe(row);
    });

    card.addEventListener('click', e => {
      if (row._wasTouched) { row._wasTouched = false; return; }
      if (e.target.closest('.ch-action') || e.target.closest('.ch-timer-btns')) return;
      if (card.classList.contains('timer-active')) return;
      if (row._swiped) { closeChallengeSwipe(row); return; }
      const c = state.challenges.find(x => x.id === row.dataset.id);
      if (c) openEditChallenge(c);
    });
  });
}

function openChallengeSwipe(row) {
  closeAllChallengeSwipes();
  const card = row.querySelector('.challenge-card');
  card.style.transition = `transform 0.28s var(--ease-out)`;
  card.style.transform = `translateX(-${CH_SWIPE_W}px)`;
  row._swiped = true;
}

function closeChallengeSwipe(row) {
  const card = row.querySelector('.challenge-card');
  card.style.transition = `transform 0.28s var(--ease-out)`;
  card.style.transform = 'translateX(0)';
  row._swiped = false;
}

function closeAllChallengeSwipes() {
  document.querySelectorAll('.challenge-row').forEach(r => { if (r._swiped) closeChallengeSwipe(r); });
}

document.addEventListener('touchstart', e => {
  if (!e.target.closest('.goal-row')) closeAllGoalSwipes();
  if (!e.target.closest('.challenge-row')) closeAllChallengeSwipes();
}, { passive: true });

document.addEventListener('click', e => {
  if (!e.target.closest('.goal-row')) closeAllGoalSwipes();
  if (!e.target.closest('.challenge-row')) closeAllChallengeSwipes();
});

/* ── SAVE CHALLENGE ── */
document.getElementById('save-challenge').addEventListener('click', () => {
  const name = document.getElementById('new-name').value.trim();
  if (!name || !addSelectedCat) return;
  const tRaw    = parseInt(document.getElementById('t-val').value);
  const target  = (!isNaN(tRaw) && tRaw >= 1) ? Math.min(3650, tRaw) : addTarget;
  const durRaw  = parseInt(document.getElementById('dur-val').value);
  const duration = (!isNaN(durRaw) && durRaw >= 1) ? durRaw : addDuration;
  const bedtime  = document.getElementById('add-bedtime').value || '';
  const cat      = addSelectedCat.id;

  if (editChallengeId) {
    const c = state.challenges.find(x => x.id === editChallengeId);
    if (c) {
      c.name     = name;
      c.emoji    = addSelectedCat.emoji;
      c.color    = addSelectedCat.color;
      c.category = cat;
      c.subtype  = addSubtype || '';
      c.duration = HAS_DURATION.has(cat) ? duration : null;
      c.bedtime  = HAS_BEDTIME.has(cat)  ? bedtime  : null;
      c.target   = target;
    }
    editChallengeId = null;
  } else {
    state.challenges.push({
      id: uid(), name,
      emoji: addSelectedCat.emoji,
      color: addSelectedCat.color,
      category: cat,
      subtype:  addSubtype || '',
      duration: HAS_DURATION.has(cat) ? duration : null,
      bedtime:  HAS_BEDTIME.has(cat)  ? bedtime  : null,
      progress: 0, target,
      completions: [], createdAt: today(),
    });
  }
  save();
  showTab('tab-home');
});

document.getElementById('t-minus').addEventListener('click', () => {
  addTarget = Math.max(1, addTarget - 1);
  document.getElementById('t-val').value = addTarget;
  syncPresets('t-presets', addTarget);
});
document.getElementById('t-plus').addEventListener('click', () => {
  addTarget = Math.min(3650, addTarget + 1);
  document.getElementById('t-val').value = addTarget;
  syncPresets('t-presets', addTarget);
});
document.getElementById('t-val').addEventListener('input', () => {
  const v = parseInt(document.getElementById('t-val').value);
  if (!isNaN(v) && v >= 1) addTarget = Math.min(3650, v);
  syncPresets('t-presets', addTarget);
});
document.getElementById('t-presets').addEventListener('click', e => {
  const btn = e.target.closest('.preset-btn');
  if (!btn) return;
  addTarget = Number(btn.dataset.days);
  document.getElementById('t-val').value = addTarget;
  syncPresets('t-presets', addTarget);
});
document.getElementById('dur-minus').addEventListener('click', () => {
  addDuration = Math.max(1, addDuration - 5);
  document.getElementById('dur-val').value = addDuration;
  syncDurPresets(addDuration);
});
document.getElementById('dur-plus').addEventListener('click', () => {
  addDuration = Math.min(240, addDuration + 5);
  document.getElementById('dur-val').value = addDuration;
  syncDurPresets(addDuration);
});
document.getElementById('dur-val').addEventListener('input', () => {
  const v = parseInt(document.getElementById('dur-val').value);
  if (!isNaN(v) && v >= 1) addDuration = Math.min(240, v);
  syncDurPresets(addDuration);
});
document.getElementById('dur-presets').addEventListener('click', e => {
  const btn = e.target.closest('.preset-btn');
  if (!btn) return;
  addDuration = Number(btn.dataset.mins);
  document.getElementById('dur-val').value = addDuration;
  syncDurPresets(addDuration);
});

/* ── GOAL MODAL ── */
let goalSelectedCat = null;
let goalTarget = 365;

document.getElementById('add-goal-btn').addEventListener('click', openGoalModal);

function openGoalModal() {
  goalSelectedCat = null;
  goalTarget = 365;
  document.getElementById('g-val').value = goalTarget;
  syncPresets('g-presets', goalTarget);
  document.getElementById('goal-name').value = '';
  buildCatGrid('goal-cat-grid', (cat) => {
    goalSelectedCat = cat;
    document.getElementById('goal-name').value = cat.name;
  });
  document.getElementById('goal-modal').classList.remove('hidden');
}

document.getElementById('close-modal').addEventListener('click', () => {
  document.getElementById('goal-modal').classList.add('hidden');
});
document.getElementById('goal-modal').addEventListener('click', (e) => {
  if (e.target === document.getElementById('goal-modal'))
    document.getElementById('goal-modal').classList.add('hidden');
});
document.getElementById('g-minus').addEventListener('click', () => {
  goalTarget = Math.max(1, goalTarget - 1);
  document.getElementById('g-val').value = goalTarget;
  syncPresets('g-presets', goalTarget);
});
document.getElementById('g-plus').addEventListener('click', () => {
  goalTarget = Math.min(3650, goalTarget + 1);
  document.getElementById('g-val').value = goalTarget;
  syncPresets('g-presets', goalTarget);
});
document.getElementById('g-val').addEventListener('input', () => {
  const v = parseInt(document.getElementById('g-val').value);
  if (!isNaN(v) && v >= 1) goalTarget = Math.min(3650, v);
  syncPresets('g-presets', goalTarget);
});
document.getElementById('g-presets').addEventListener('click', e => {
  const btn = e.target.closest('.preset-btn');
  if (!btn) return;
  goalTarget = Number(btn.dataset.days);
  document.getElementById('g-val').value = goalTarget;
  syncPresets('g-presets', goalTarget);
});
document.getElementById('save-goal').addEventListener('click', () => {
  const name = document.getElementById('goal-name').value.trim();
  if (!name) return;
  const gRaw = parseInt(document.getElementById('g-val').value);
  const target = (!isNaN(gRaw) && gRaw >= 1) ? Math.min(3650, gRaw) : goalTarget;
  state.goals.push({
    id: uid(),
    name,
    emoji: goalSelectedCat ? goalSelectedCat.emoji : '🎯',
    color: goalSelectedCat ? goalSelectedCat.color : 'blue',
    progress: 0,
    target,
  });
  save();
  document.getElementById('goal-modal').classList.add('hidden');
  renderHome();
});

/* ── BOTTOM NAV ── */
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => showTab(btn.dataset.tab));
});
document.getElementById('nav-fab').addEventListener('click', () => showTab('tab-add'));
document.getElementById('home-avatar-btn').addEventListener('click', () => showTab('tab-profile'));

/* ── PROFILE ACTIONS ── */
document.getElementById('edit-name-btn').addEventListener('click', () => {
  const name = prompt('Nouveau prénom :', state.user.name);
  if (name && name.trim()) {
    state.user.name = name.trim();
    save();
    renderProfile();
    document.getElementById('user-name-display').textContent = state.user.name;
  }
});
document.getElementById('reset-btn').addEventListener('click', () => {
  if (confirm('Réinitialiser toutes les données ?')) {
    localStorage.removeItem('perfectday');
    location.reload();
  }
});

/* ── ONBOARDING ── */
let obChallenges = [];   // list of configured challenges
let obCurrentCat = null; // category currently open in form
let obChTarget   = 365;
let obChDuration = 20;
let obChSubtype  = '';

function fmtDays(days) {
  if (days >= 1825) return '5 ans';
  if (days >= 365)  return '1 an';
  if (days >= 30)   return `${Math.round(days / 30)} mois`;
  return `${days} jours`;
}

function buildOnboardingGrid() {
  const grid = document.getElementById('cat-grid');
  grid.innerHTML = CATEGORIES.map(c => `
    <div class="cat-item" data-id="${c.id}">
      <span class="cat-emoji">${c.emoji}</span>
      <span class="cat-name">${c.name}</span>
    </div>`).join('');
  grid.querySelectorAll('.cat-item').forEach(item => {
    item.addEventListener('click', () => {
      const cat = CATEGORIES.find(c => c.id === item.dataset.id);
      if (!cat) return;
      if (obCurrentCat && obCurrentCat.id === cat.id) { closeObForm(); return; }
      openObForm(cat);
    });
  });
}

function openObForm(cat) {
  obCurrentCat = cat;
  obChTarget   = 365;
  obChDuration = 20;
  obChSubtype  = '';

  document.querySelectorAll('#cat-grid .cat-item').forEach(el => {
    if (!el.classList.contains('done'))
      el.classList.toggle('selected', el.dataset.id === cat.id);
  });

  document.getElementById('ob-form-emoji').textContent = cat.emoji;
  document.getElementById('ob-ch-name').value = cat.name;

  /* Subtypes */
  const subtypes = CATEGORY_SUBTYPES[cat.id] || [];
  const stWrap  = document.getElementById('ob-ch-subtype-wrap');
  const stChips = document.getElementById('ob-ch-subtype-chips');
  if (subtypes.length) {
    stChips.innerHTML = subtypes.map(s =>
      `<button class="subtype-chip" data-val="${s}">${s}</button>`).join('');
    stWrap.classList.remove('hidden');
    stChips.querySelectorAll('.subtype-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        stChips.querySelectorAll('.subtype-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        obChSubtype = chip.dataset.val;
      });
    });
  } else {
    stWrap.classList.add('hidden');
  }

  /* Duration */
  const durWrap = document.getElementById('ob-ch-dur-wrap');
  if (HAS_DURATION.has(cat.id)) {
    syncObDurPresets(obChDuration);
    durWrap.classList.remove('hidden');
  } else {
    durWrap.classList.add('hidden');
  }
  syncObTargetPresets(obChTarget);

  const form = document.getElementById('ob-ch-form');
  form.classList.remove('hidden');
  setTimeout(() => form.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 60);
}

function closeObForm() {
  document.getElementById('ob-ch-form').classList.add('hidden');
  if (obCurrentCat) {
    const el = document.querySelector(`#cat-grid .cat-item[data-id="${obCurrentCat.id}"]`);
    if (el && !el.classList.contains('done')) el.classList.remove('selected');
  }
  obCurrentCat = null;
}

function syncObTargetPresets(val) {
  document.querySelectorAll('#ob-target-presets .preset-btn').forEach(btn => {
    btn.classList.toggle('active', Number(btn.dataset.days) === val);
  });
}
function syncObDurPresets(val) {
  document.querySelectorAll('#ob-dur-presets .preset-btn').forEach(btn => {
    btn.classList.toggle('active', Number(btn.dataset.mins) === val);
  });
}

function renderObChallengesList() {
  const el = document.getElementById('ob-challenges-list');
  if (!obChallenges.length) { el.innerHTML = ''; return; }
  el.innerHTML = obChallenges.map((c, i) => `
    <div class="ob-ch-item">
      <span class="ob-ch-emoji">${c.emoji}</span>
      <div class="ob-ch-info">
        <div class="ob-ch-name-txt">${c.name}</div>
        <div class="ob-ch-meta">${c.duration ? c.duration + ' min · ' : ''}${fmtDays(c.target)}</div>
      </div>
      <button class="ob-goal-del" data-i="${i}">✕</button>
    </div>`).join('');
  el.querySelectorAll('.ob-goal-del').forEach(btn => {
    btn.addEventListener('click', () => {
      const removed = obChallenges.splice(Number(btn.dataset.i), 1)[0];
      if (removed) {
        const catEl = document.querySelector(`#cat-grid .cat-item[data-id="${removed.catId}"]`);
        if (catEl) catEl.classList.remove('done', 'selected');
      }
      renderObChallengesList();
      updateObStartBtn();
    });
  });
}

function updateObStartBtn() {
  const name = document.getElementById('ob-name').value.trim();
  document.getElementById('ob-start').disabled = !(name && obChallenges.length > 0);
}

document.getElementById('ob-name').addEventListener('input', updateObStartBtn);

document.getElementById('ob-target-presets').addEventListener('click', e => {
  const btn = e.target.closest('.preset-btn');
  if (!btn) return;
  obChTarget = Number(btn.dataset.days);
  syncObTargetPresets(obChTarget);
});

document.getElementById('ob-dur-presets').addEventListener('click', e => {
  const btn = e.target.closest('.preset-btn');
  if (!btn) return;
  obChDuration = Number(btn.dataset.mins);
  syncObDurPresets(obChDuration);
});

document.getElementById('ob-ch-cancel').addEventListener('click', closeObForm);

document.getElementById('ob-ch-confirm').addEventListener('click', () => {
  const name = document.getElementById('ob-ch-name').value.trim();
  if (!name || !obCurrentCat) return;
  const cat = obCurrentCat;
  obChallenges.push({
    catId:    cat.id,
    name,
    emoji:    cat.emoji,
    color:    cat.color,
    category: cat.id,
    subtype:  obChSubtype || '',
    duration: HAS_DURATION.has(cat.id) ? obChDuration : null,
    target:   obChTarget,
  });
  const catEl = document.querySelector(`#cat-grid .cat-item[data-id="${cat.id}"]`);
  if (catEl) { catEl.classList.remove('selected'); catEl.classList.add('done'); }
  closeObForm();
  renderObChallengesList();
  updateObStartBtn();
});

document.getElementById('ob-start').addEventListener('click', () => {
  const name = document.getElementById('ob-name').value.trim();
  if (!name || obChallenges.length === 0) return;
  state.user.name      = name;
  state.user.onboarded = true;
  obChallenges.forEach(c => {
    state.challenges.push({
      id: uid(), name: c.name, emoji: c.emoji,
      color: c.color, category: c.catId,
      subtype:  c.subtype || '',
      duration: c.duration || null,
      bedtime:  null,
      progress: 0, target: c.target,
      completions: [], createdAt: today(),
    });
  });
  save();
  enterApp();
});

/* ── SCOREBOARD ACTIONS ── */
document.getElementById('share-score-btn').addEventListener('click', () => {
  const url = generateShareURL();
  navigator.clipboard.writeText(url).then(() => {
    showToast('🔗 Lien copié ! Envoie-le à tes amis.');
  }).catch(() => {
    prompt('Copie ce lien :', url);
  });
});

document.getElementById('add-friend-btn').addEventListener('click', () => {
  const url = prompt('Colle le lien de ton ami :');
  if (!url) return;
  const data = parseFriendURL(url);
  if (!data?.n) { showToast('❌ Lien invalide'); return; }
  addFriend(data);
  renderScoreboard();
  showToast(`✅ ${data.n} ajouté au classement !`);
});

/* ── INIT ── */
function enterApp() {
  showScreen('app');
  showTab('tab-home');
}

function init() {
  load();
  buildOnboardingGrid();
  checkShareURL();
  setTimeout(() => {
    if (state.user.onboarded) {
      enterApp();
    } else {
      showScreen('onboarding');
    }
  }, 1200);
}

init();
